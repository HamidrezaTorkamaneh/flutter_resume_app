package com.example.flutter_resume_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
