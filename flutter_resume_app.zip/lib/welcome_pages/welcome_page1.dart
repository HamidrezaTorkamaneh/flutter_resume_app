import 'package:flutter/material.dart';
import 'package:flutter_resume_app/welcome_pages/welcome_page2.dart';
import 'package:flutter_resume_app/global.dart' as globalParameter;

class firstWelcome extends StatelessWidget {
  const firstWelcome({super.key});

  @override
  Widget build(BuildContext context) {
    double unitHeightValue = MediaQuery.of(context).size.height * 0.01;

    return SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(height: 10),
          Text(
            'سلام به برنامه رزومه خوش آمدید',
            style: TextStyle(
              fontSize: globalParameter.titleFontSize * unitHeightValue,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 20.0),
          Expanded(
            child: Image(
              image: AssetImage('images/welcome.jpg'),
              fit: BoxFit.fill,
            ),
          ),
          SizedBox(height: 50.0),
          Padding(
            padding: EdgeInsets.all(10),
            child: Text(
              'در این برنامه میتوانید رزومه خود را آپلود کنید و کارفرمایان آن را بررسی و در صورت پذیرش با شما گفتگو کنند.',
              textAlign: TextAlign.right,
              textDirection: TextDirection.rtl,
              style: TextStyle(
                  fontSize: globalParameter.detailFontSize * unitHeightValue,
                  fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 200.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.all(5),
              ),
              TextButton(
                style: TextButton.styleFrom(
                  minimumSize: Size(100, 40),
                ),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) => secondWelcome(),
                    ),
                  );
                },
                child: Row(
                  children: [
                    Text(
                      'بعدی',
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize:
                            globalParameter.buttonFontSize * unitHeightValue,
                      ),
                    ),
                    SizedBox(width: 10),
                    Icon(
                      Icons.arrow_forward_ios,
                      color: Colors.blue,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
