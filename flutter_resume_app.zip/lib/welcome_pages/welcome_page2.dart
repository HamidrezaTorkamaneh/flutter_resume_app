import 'package:flutter/material.dart';
import 'package:flutter_resume_app/welcome_pages/welcome_page3.dart';
import 'package:flutter_resume_app/global.dart' as globalParameter;

class secondWelcome extends StatelessWidget {
  const secondWelcome({super.key});

  @override
  Widget build(BuildContext context) {
    double unitHeightValue = MediaQuery.of(context).size.height * 0.01;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        body: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Image(
                  image: AssetImage('images/a.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
              SizedBox(height: 50.0),
              Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  'بعد از توافقات بین کارفرما و پیمانکار ، هزینه پروژه از کارفرما در حساب این برنامه بلوکه میشود تا زمان اتمام پروژه.',
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: globalParameter.detailFontSize * unitHeightValue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 200.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(0),
                  ),
                  TextButton.icon(
                    style: TextButton.styleFrom(
                      minimumSize: Size(100, 40),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    label: Text(
                      'قبلی',
                      style: TextStyle(
                          fontSize:
                              globalParameter.buttonFontSize * unitHeightValue),
                    ),
                    icon: Icon(
                      Icons.arrow_back_ios_new,
                      color: Colors.blue,
                    ),
                  ),
                  SizedBox(width: 210),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(100, 40),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) => thirdWelcome(),
                        ),
                      );
                    },
                    child: Row(
                      children: [
                        Text(
                          'بعدی',
                          style: TextStyle(
                            fontSize: globalParameter.buttonFontSize *
                                unitHeightValue,
                          ),
                        ),
                        SizedBox(width: 10),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.blue,
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
