import 'package:flutter/material.dart';
import 'package:flutter_resume_app/welcome_pages/welcome_page4.dart';
import 'package:flutter_resume_app/global.dart' as globalParameter;

class thirdWelcome extends StatelessWidget {
  const thirdWelcome({super.key});

  @override
  Widget build(BuildContext context) {
    double unitHeightValue = MediaQuery.of(context).size.height * 0.01;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        body: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Image(
                  image: AssetImage('images/r.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
              SizedBox(height: 50.0),
              Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  'بعد از اتمام پروژه و درصورتی که پروژه به نحوه احسنت انجام شده، علاوه بر اینکه کارفرما به شما امتیاز و نکات مثبت و منفی را ثبت میکند، رتبه شما هم در آن حوزه بالا میرود.',
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: globalParameter.detailFontSize * unitHeightValue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 200.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(0),
                  ),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(100, 40),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios_new,
                          color: Colors.blue,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'قبلی',
                          style: TextStyle(
                            fontSize: globalParameter.buttonFontSize *
                                unitHeightValue,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 210),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(100, 40),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) => fourthWelcome(),
                        ),
                      );
                    },
                    child: Row(
                      children: [
                        Text(
                          'بعدی',
                          style: TextStyle(
                            fontSize: globalParameter.buttonFontSize *
                                unitHeightValue,
                          ),
                        ),
                        SizedBox(width: 10),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Colors.blue,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
