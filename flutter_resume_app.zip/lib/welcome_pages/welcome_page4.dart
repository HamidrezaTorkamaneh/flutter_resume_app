import 'package:flutter/material.dart';
import 'package:flutter_resume_app/start_page..dart';
import 'package:flutter_resume_app/global.dart' as globalParameter;

class fourthWelcome extends StatelessWidget {
  const fourthWelcome({super.key});

  @override
  Widget build(BuildContext context) {
    double unitHeightValue = MediaQuery.of(context).size.height * 0.01;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        body: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Expanded(
                child: Image(
                  image: AssetImage('images/h.png'),
                  fit: BoxFit.fill,
                ),
              ),
              SizedBox(height: 50.0),
              Padding(
                padding: EdgeInsets.all(10),
                child: Text(
                  'یک خبر خوب هم برای پیمانکاران دارم اینکه شما میتونید با همکاری یک پیمانکار دیگر پروژه ای را قبول و انجام دهید.',
                  textAlign: TextAlign.right,
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontSize: globalParameter.detailFontSize * unitHeightValue,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 200.0),
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(0),
                  ),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(100, 40),
                    ),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios_new,
                          color: Colors.blue,
                        ),
                        SizedBox(width: 10),
                        Text(
                          'قبلی',
                          style: TextStyle(
                            fontSize: globalParameter.buttonFontSize *
                                unitHeightValue,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 163),
                  TextButton(
                      style: TextButton.styleFrom(
                        minimumSize: Size(100, 40),
                      ),
                      onPressed: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (BuildContext context) => startPage(),
                          ),
                        );
                      },
                      child: Row(
                        children: [
                          Text(
                            'شروع برنامه ',
                            style: TextStyle(
                              fontSize: globalParameter.buttonFontSize *
                                  unitHeightValue,
                            ),
                          ),
                          SizedBox(width: 10),
                          Icon(
                            Icons.arrow_forward_ios,
                            color: Colors.blue,
                          ),
                        ],
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
