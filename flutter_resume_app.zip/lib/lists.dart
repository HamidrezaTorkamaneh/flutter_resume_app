import 'package:flutter/material.dart';
import 'package:flutter_resume_app/appbar.dart';
import 'package:flutter_resume_app/programming_pages/programming_people.dart';

class listsProgramming extends StatelessWidget {
  const listsProgramming({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        appBar: getappBar(context),
        body: SafeArea(
          child: Container(
            width: 500.0,
            height: 1000.0,
            child: DecoratedBox(
              position: DecorationPosition.background,
              decoration: BoxDecoration(
                color: Colors.red,
                image: DecorationImage(
                  image: AssetImage('images/red.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(width: 3, color: Colors.orangeAccent),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) =>
                              programming_people(),
                        ),
                      );
                    },
                    child: Text(
                      ' تحت موبایل',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 50.0),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(
                        width: 3,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      'تحت وب',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 50.0),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(
                        width: 3,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      'هوش مصنوعی',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
