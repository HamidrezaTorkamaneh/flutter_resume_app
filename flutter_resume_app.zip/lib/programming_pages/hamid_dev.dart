import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class hamidDev extends StatelessWidget {
  const hamidDev({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        appBar: AppBar(
          centerTitle: true,
          elevation: 6.0,
          title: Text(
            'حمیدرضا ترکمانه',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: Colors.red,
          leading: IconButton(
            color: Colors.white,
            icon: Icon(Icons.arrow_back_outlined),
            iconSize: 30.0,
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: _getBody(),
      ),
    );
  }

  Widget _getBody() {
    return SafeArea(
      child: Column(
        children: [
          SizedBox(
            height: 20.0,
          ),
          Center(
            child: Container(
              width: 150.0,
              height: 150.0,
              child: CircleAvatar(
                backgroundImage: AssetImage('images/user.jpg'),
              ),
            ),
          ),
          SizedBox(height: 20.0),
          Text(
            'حمیدرضا ترکمانه هستم ، برنامه نویس فلاتر',
            style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10.0),
          Padding(
            padding: EdgeInsets.all(10),
            child: Text(
              'در تلاش برای حرفه شدن در برنامه نویسی موبابل و تمام موضوعات در این حوضه ',
              textAlign: TextAlign.center,
            ),
          ),
          _getIcons(),
          SizedBox(height: 12.0),
          _getSkillsTitle(),
          SizedBox(height: 12.0),
          _getResume(),
        ],
      ),
    );
  }

  Widget _getIcons() {
    return Wrap(
      children: [
        IconButton(
          onPressed: () {},
          icon: FaIcon(
            FontAwesomeIcons.whatsapp,
            color: Colors.green,
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: FaIcon(
            FontAwesomeIcons.instagram,
            color: Color.fromARGB(255, 255, 87, 143),
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: FaIcon(
            FontAwesomeIcons.linkedin,
            color: Color.fromARGB(255, 60, 118, 165),
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: FaIcon(FontAwesomeIcons.github),
        ),
        IconButton(
          onPressed: () {},
          icon: FaIcon(
            FontAwesomeIcons.telegram,
            color: Colors.blueAccent,
          ),
        ),
        IconButton(
          onPressed: () {},
          icon: FaIcon(
            FontAwesomeIcons.googlePlay,
            color: Color.fromARGB(255, 0, 255, 76),
          ),
        ),
      ],
    );
  }

  Widget _getSkillsTitle() {
    var list = ['android', 'dart', 'flutter', 'java'];
    return Wrap(
      spacing: 15.0,
      children: [
        for (var skill in list)
          Card(
            elevation: 6.0,
            shadowColor: Color.fromARGB(255, 65, 38, 36),
            child: Column(
              children: [
                Container(
                  width: 50.0,
                  height: 50.0,
                  child: Image(
                    image: AssetImage('images/$skill.png'),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text('$skill'),
                )
              ],
            ),
          ),
      ],
    );
  }

  Widget _getResume() {
    var list = [
      '۱- در سال ۹۹ استخدام شرکت برنامه نویسی و در حوزه اندروید کار کردم.  ',
      '۲- درسال ۱۴۰۱ فریلنسر کار کردم .',
      '۳- سال ۱۴۰۴ شرکت برنامه نویسی تاسیس کردم.'
    ];
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      width: double.infinity,
      color: Colors.grey[200],
      child: Column(
        children: [
          Text(
            '((سابقه کار))',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              SizedBox(
                width: double.infinity,
                height: 6.0,
              ),
              for (var title in list)
                Text(
                  title,
                  textDirection: TextDirection.rtl,
                ),
            ],
          )
        ],
      ),
    );
  }
}
