import 'package:flutter/material.dart';
import 'package:flutter_resume_app/appbar.dart';
import 'package:flutter_resume_app/programming_pages/sepehr_dev.dart';
import 'hamid_dev.dart';

class programming_people extends StatelessWidget {
  const programming_people({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        appBar: getappBar(context),
        body: SafeArea(
          child: Container(
            width: 500.0,
            height: 1000.0,
            child: DecoratedBox(
              position: DecorationPosition.background,
              decoration: BoxDecoration(
                color: Colors.red,
                image: DecorationImage(
                  image: AssetImage('images/red.jpg'),
                  fit: BoxFit.fill,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(width: 3, color: Colors.orangeAccent),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) => hamidDev(),
                        ),
                      );
                    },
                    child: Text(
                      'حمیدرضا ترکمانه',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(
                        width: 3,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) => sepehrDev(),
                        ),
                      );
                    },
                    child: Text(
                      'سپهر درویشی',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(
                        width: 3,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      'مهدی اضغری',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  TextButton(
                    style: TextButton.styleFrom(
                      minimumSize: Size(200, 40),
                      backgroundColor: Colors.redAccent,
                      side: BorderSide(
                        width: 3,
                        color: Colors.orangeAccent,
                      ),
                    ),
                    onPressed: () {},
                    child: Text(
                      'علیرضا احدی',
                      style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 22.0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
