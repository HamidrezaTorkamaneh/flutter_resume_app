import 'package:flutter/material.dart';

PreferredSizeWidget getappBar(context) {
  return AppBar(
    backgroundColor: Colors.red,
    centerTitle: true,
    title: Text(
      'Resume',
      style: TextStyle(
        fontSize: 26.0,
        fontWeight: FontWeight.bold,
      ),
    ),
    leading: IconButton(
      color: Colors.white,
      icon: Icon(Icons.arrow_back_outlined),
      iconSize: 30.0,
      onPressed: () {
        Navigator.pop(context);
      },
    ),
  );
}
