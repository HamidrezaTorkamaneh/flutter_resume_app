import 'package:flutter/material.dart';
import 'package:flutter_resume_app/list_page.dart';

import 'appbar.dart';

class startPage extends StatelessWidget {
  const startPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'vazir'),
      home: Scaffold(
        appBar: getappBar(context),
        body: SafeArea(
          child: Container(
            width: 500.0,
            height: 1000.0,
            child: DecoratedBox(
                position: DecorationPosition.background,
                decoration: BoxDecoration(
                  color: Colors.red,
                  image: DecorationImage(
                    image: AssetImage('images/red.jpg'),
                    fit: BoxFit.fill,
                  ),
                ),
                child: _getButtons(context)),
          ),
        ),
      ),
    );
  }

  Widget _getButtons(context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        TextButton(
          style: TextButton.styleFrom(
            minimumSize: Size(200, 40),
            backgroundColor: Colors.redAccent,
            side: BorderSide(width: 3, color: Colors.orangeAccent),
          ),
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (BuildContext context) => listPage(),
              ),
            );
          },
          child: Text(
            'لیست رزومه ها',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 22.0,
            ),
          ),
        ),
        SizedBox(height: 50.0),
        TextButton(
          style: TextButton.styleFrom(
            minimumSize: Size(200, 40),
            backgroundColor: Colors.redAccent,
            side: BorderSide(
              width: 3,
              color: Colors.orangeAccent,
            ),
          ),
          onPressed: () {},
          child: Text(
            'ثبت رزومه',
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: 22.0,
            ),
          ),
        ),
      ],
    );
  }
}
