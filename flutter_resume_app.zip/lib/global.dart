library global;

//font size
double buttonFontSize = 2;
double detailFontSize = 2.2;
double titleFontSize = 2.7;
